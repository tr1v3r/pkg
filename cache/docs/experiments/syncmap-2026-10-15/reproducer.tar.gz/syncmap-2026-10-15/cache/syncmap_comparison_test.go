package cache

import (
	"errors"
	"fmt"
	"math"
	"math/rand"
	"runtime"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

type experimentCache interface {
	Set(int, int, time.Duration) error
	Get(int) (int, bool)
	Delete(int)
	Close()
	nextDelay() (time.Duration, bool)
}

type experimentFactory struct {
	name string
	new  func() experimentCache
}

var experimentFactories = []experimentFactory{
	{"DoubleLock", func() experimentCache { return New[int, int]() }},
	{"SyncMap", func() experimentCache { return newSyncMap[int, int]() }},
}

func assertExperimentInvariants(t *testing.T, c experimentCache) {
	t.Helper()
	switch c := c.(type) {
	case *Cache[int, int]:
		c.heapMu.Lock()
		defer c.heapMu.Unlock()
		if len(c.items) != len(c.expirations) {
			t.Fatal("map/heap length mismatch")
		}
		for i, item := range c.expirations {
			if item.index != i || c.items[item.key] != item {
				t.Fatal("map/heap index mismatch")
			}
			if i > 0 && c.expirations.Less(i, (i-1)/2) {
				t.Fatal("heap order violated")
			}
		}
	case *syncMapCache[int, int]:
		c.heapMu.Lock()
		defer c.heapMu.Unlock()
		count := 0
		c.items.Range(func(_, _ any) bool { count++; return true })
		if count != len(c.expirations) {
			t.Fatal("sync.Map/heap length mismatch")
		}
		for i, item := range c.expirations {
			stored, ok := c.items.Load(item.key)
			if !ok || stored != item || item.index != i {
				t.Fatal("sync.Map/heap index mismatch")
			}
			if i > 0 && c.expirations.Less(i, (i-1)/2) {
				t.Fatal("heap order violated")
			}
		}
	}
}

func TestExperimentModel(t *testing.T) {
	for _, f := range experimentFactories {
		t.Run(f.name, func(t *testing.T) {
			c := f.new()
			defer c.Close()
			model := make(map[int]int)
			rng := rand.New(rand.NewSource(42))
			for i := 0; i < 10000; i++ {
				key := rng.Intn(128)
				switch rng.Intn(4) {
				case 0, 1:
					value := rng.Int()
					if err := c.Set(key, value, time.Hour); err != nil {
						t.Fatal(err)
					}
					model[key] = value
				case 2:
					c.Delete(key)
					delete(model, key)
				case 3:
					value, ok := c.Get(key)
					want, exists := model[key]
					if value != want || ok != exists {
						t.Fatalf("key=%d got=(%d,%t) want=(%d,%t)", key, value, ok, want, exists)
					}
				}
				assertExperimentInvariants(t, c)
			}
			if err := c.Set(0, 99, 0); !errors.Is(err, ErrInvalidTTL) {
				t.Fatal(err)
			}
			c.Close()
			if err := c.Set(0, 99, time.Hour); !errors.Is(err, ErrClosed) {
				t.Fatal(err)
			}
			if _, ok := c.Get(0); ok {
				t.Fatal("closed cache hit")
			}
		})
	}
}

func TestExperimentConcurrent(t *testing.T) {
	for _, f := range experimentFactories {
		t.Run(f.name, func(t *testing.T) {
			c := f.new()
			defer c.Close()
			var wg sync.WaitGroup
			for worker := 0; worker < 12; worker++ {
				wg.Add(1)
				go func(worker int) {
					defer wg.Done()
					for i := 0; i < 1500; i++ {
						key := (i + worker) % 128
						ttl := time.Hour
						if i%3 == 0 {
							ttl = time.Nanosecond
						}
						if err := c.Set(key, key, ttl); err != nil {
							t.Error(err)
							return
						}
						if value, ok := c.Get(key); ok && value != key {
							t.Error("corrupt snapshot")
							return
						}
						if i%5 == 0 {
							c.Delete((key + 1) % 128)
						}
						if i%7 == 0 {
							c.nextDelay()
						}
					}
				}(worker)
			}
			wg.Wait()
			assertExperimentInvariants(t, c)
			wg.Add(12)
			for worker := 0; worker < 12; worker++ {
				go func() { defer wg.Done(); c.Close() }()
			}
			wg.Wait()
		})
	}
}

func TestExperimentSyncMapSnapshotsAndValidation(t *testing.T) {
	c := newSyncMap[float64, *int]()
	defer c.Close()
	if err := c.Set(math.NaN(), nil, time.Hour); !errors.Is(err, ErrInvalidKey) {
		t.Fatal(err)
	}
	if err := c.Set(1, nil, time.Hour); err != nil {
		t.Fatal(err)
	}
	if value, ok := c.Get(1); !ok || value != nil {
		t.Fatal("nil value lost")
	}
	old, _ := c.items.Load(float64(1))
	first := old.(*entry[float64, *int])
	deadline := first.deadline
	n := 42
	if err := c.Set(1, &n, time.Hour); err != nil {
		t.Fatal(err)
	}
	if first.value != nil || !first.deadline.Equal(deadline) {
		t.Fatal("published snapshot mutated")
	}
	c.heapMu.Lock()
	defer c.heapMu.Unlock()
	if len(c.expirations) != 1 {
		t.Fatal("refresh accumulated nodes")
	}
}

func experimentPopulate(b *testing.B, f experimentFactory, entries int) experimentCache {
	b.Helper()
	c := f.new()
	b.Cleanup(c.Close)
	for key := 0; key < entries; key++ {
		if err := c.Set(key, key, 24*time.Hour); err != nil {
			b.Fatal(err)
		}
	}
	return c
}

func BenchmarkExperiment(b *testing.B) {
	for _, scenario := range []string{"GetHit1024", "GetMiss1024", "ReadParallel65536", "Overwrite1", "Overwrite1024", "Overwrite65536", "SetDelete1024", "Mixed95Read65536", "Mixed50Read65536", "Mixed95ReadHot64"} {
		b.Run(scenario, func(b *testing.B) {
			for _, f := range experimentFactories {
				b.Run(f.name, func(b *testing.B) {
					entries := 1024
					switch scenario {
					case "ReadParallel65536", "Overwrite65536", "Mixed95Read65536", "Mixed50Read65536":
						entries = 65536
					case "Overwrite1":
						entries = 1
					case "Mixed95ReadHot64":
						entries = 64
					}
					c := experimentPopulate(b, f, entries)
					runtime.GC()
					var before, after runtime.MemStats
					runtime.ReadMemStats(&before)
					b.ReportAllocs()
					b.ResetTimer()
					switch scenario {
					case "GetHit1024":
						for i := 0; i < b.N; i++ {
							if v, ok := c.Get(i & 1023); !ok || v != i&1023 {
								b.Fatal("bad hit")
							}
						}
					case "GetMiss1024":
						for i := 0; i < b.N; i++ {
							if _, ok := c.Get(-1); ok {
								b.Fatal("bad miss")
							}
						}
					case "Overwrite1", "Overwrite1024", "Overwrite65536":
						for i := 0; i < b.N; i++ {
							if err := c.Set(i&(entries-1), i, 24*time.Hour); err != nil {
								b.Fatal(err)
							}
						}
					case "SetDelete1024":
						for i := 0; i < b.N; i++ {
							if err := c.Set(1024, i, 24*time.Hour); err != nil {
								b.Fatal(err)
							}
							c.Delete(1024)
						}
					default:
						var sequence atomic.Uint64
						b.RunParallel(func(pb *testing.PB) {
							state := sequence.Add(1) * 0x9e3779b97f4a7c15
							for pb.Next() {
								state ^= state << 13
								state ^= state >> 7
								state ^= state << 17
								key := int(state>>32) & (entries - 1)
								reads := 95
								if scenario == "Mixed50Read65536" {
									reads = 50
								}
								if scenario == "ReadParallel65536" || state%100 < uint64(reads) {
									if v, ok := c.Get(key); !ok || v != key {
										b.Error("bad parallel hit")
										return
									}
								} else if err := c.Set(key, key, 24*time.Hour); err != nil {
									b.Error(err)
									return
								}
							}
						})
					}
					b.StopTimer()
					runtime.ReadMemStats(&after)
					b.ReportMetric(float64(after.NumGC-before.NumGC)*1e6/float64(b.N), "GC/Mop")
				})
			}
		})
	}
}

func TestExperimentFootprint(t *testing.T) {
	t.Logf("%s GOMAXPROCS=%d", runtime.Version(), runtime.GOMAXPROCS(0))
	const entries = 100000
	for _, f := range experimentFactories {
		for run := 0; run < 3; run++ {
			runtime.GC()
			var before, after runtime.MemStats
			runtime.ReadMemStats(&before)
			c := f.new()
			for key := 0; key < entries; key++ {
				if err := c.Set(key, key, 24*time.Hour); err != nil {
					t.Fatal(err)
				}
			}
			runtime.GC()
			runtime.ReadMemStats(&after)
			t.Logf("%s run=%d retained=%d bytes (%.2f B/key) objects=%d", f.name, run, int64(after.HeapAlloc)-int64(before.HeapAlloc), float64(int64(after.HeapAlloc)-int64(before.HeapAlloc))/entries, int64(after.HeapObjects)-int64(before.HeapObjects))
			runtime.KeepAlive(c)
			c.Close()
		}
	}
}

func TestExperimentEnvironment(t *testing.T) {
	t.Log(fmt.Sprintf("Go=%s CPUs=%d GOMAXPROCS=%d", runtime.Version(), runtime.NumCPU(), runtime.GOMAXPROCS(0)))
}
