package cache

import (
	"fmt"
	"math/bits"
	"runtime"
	"sync/atomic"
	"testing"
	"time"
)

type experimentLatency struct {
	histogram [1025]uint64
	count     uint64
	over10us  uint64
	over1ms   uint64
	max       time.Duration
}

func (s *experimentLatency) add(d time.Duration) {
	n := uint64(d)
	index := 0
	if n > 0 {
		exponent := bits.Len64(n) - 1
		base := uint64(1) << exponent
		index = 1 + exponent*16 + int((n-base)*16/base)
	}
	s.histogram[index]++
	s.count++
	if d > 10*time.Microsecond {
		s.over10us++
	}
	if d > time.Millisecond {
		s.over1ms++
	}
	if d > s.max {
		s.max = d
	}
}

func (s *experimentLatency) quantile(percent uint64) time.Duration {
	target := (s.count*percent + 99) / 100
	var cumulative uint64
	for index, count := range s.histogram {
		cumulative += count
		if cumulative >= target {
			if index == 0 {
				return 0
			}
			exponent, slot := (index-1)/16, (index-1)%16
			base := uint64(1) << exponent
			return time.Duration(base + (base*uint64(slot+1)+15)/16 - 1)
		}
	}
	return 0
}

func experimentSeedExpired(name string, count int, identical bool) experimentCache {
	var c experimentCache
	if name == "DoubleLock" {
		cache := &Cache[int, int]{items: make(map[int]*entry[int, int], count+1), wake: make(chan struct{}, 1), stop: make(chan struct{}), done: make(chan struct{})}
		close(cache.done)
		c = cache
	} else {
		cache := &syncMapCache[int, int]{wake: make(chan struct{}, 1), stop: make(chan struct{}), done: make(chan struct{})}
		close(cache.done)
		c = cache
	}
	expired := time.Now().Add(-time.Hour)
	for key := 0; key <= count; key++ {
		deadline := expired
		if !identical {
			deadline = deadline.Add(time.Duration(key) * time.Nanosecond)
		}
		storedKey := key
		if key == count {
			storedKey = -1
			deadline = time.Now().Add(time.Hour)
		}
		item := &entry[int, int]{key: storedKey, value: 42, deadline: deadline, index: key}
		switch cache := c.(type) {
		case *Cache[int, int]:
			cache.items[storedKey] = item
			cache.expirations = append(cache.expirations, item)
		case *syncMapCache[int, int]:
			cache.items.Store(storedKey, item)
			cache.expirations = append(cache.expirations, item)
		}
	}
	return c
}

func TestExperimentExpiryContinuous(t *testing.T) {
	const readers, waves = 12, 5
	t.Logf("%s GOMAXPROCS=%d readers=%d", runtime.Version(), runtime.GOMAXPROCS(0), readers)
	for _, identical := range []bool{true, false} {
		shape := "identical"
		if !identical {
			shape = "staggered"
		}
		for _, count := range []int{10000, 100000} {
			t.Run(fmt.Sprintf("%s/N=%d", shape, count), func(t *testing.T) {
				for wave := 0; wave < waves; wave++ {
					order := []string{"DoubleLock", "SyncMap"}
					if wave%2 == 1 {
						order = []string{"SyncMap", "DoubleLock"}
					}
					for _, name := range order {
						c := experimentSeedExpired(name, count, identical)
						var phase atomic.Int32
						var bad atomic.Bool
						ready := make(chan struct{}, readers)
						results := make(chan *experimentLatency, readers)
						for reader := 0; reader < readers; reader++ {
							go func() {
								samples := new(experimentLatency)
								for i := 0; i < 1000; i++ {
									c.Get(-1)
								}
								ready <- struct{}{}
								for {
									p := phase.Load()
									if p == 2 {
										break
									}
									start := time.Now()
									v, ok := c.Get(-1)
									elapsed := time.Since(start)
									if !ok || v != 42 {
										bad.Store(true)
									}
									if p == 1 {
										samples.add(elapsed)
									}
								}
								results <- samples
							}()
						}
						for reader := 0; reader < readers; reader++ {
							<-ready
						}
						phase.Store(1)
						start := time.Now()
						c.nextDelay()
						cleanup := time.Since(start)
						phase.Store(2)
						all := new(experimentLatency)
						for reader := 0; reader < readers; reader++ {
							part := <-results
							all.count += part.count
							all.over10us += part.over10us
							all.over1ms += part.over1ms
							if part.max > all.max {
								all.max = part.max
							}
							for index, n := range part.histogram {
								all.histogram[index] += n
							}
						}
						if bad.Load() {
							t.Fatal("live read failed during cleanup")
						}
						assertExperimentInvariants(t, c)
						c.Close()
						t.Logf("%s wave=%d cleanup=%s reads=%d p50<=%s p99<=%s max=%s over10us=%d over1ms=%d", name, wave, cleanup, all.count, all.quantile(50), all.quantile(99), all.max, all.over10us, all.over1ms)
					}
				}
			})
		}
	}
}
