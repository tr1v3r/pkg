//go:build go1.25

package cache

import (
	"testing"
	"testing/synctest"
	"time"
)

func TestExperimentSyncMapScheduler(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		c := newSyncMap[int, int]()
		defer c.Close()
		set := func(key int, ttl time.Duration) {
			t.Helper()
			if err := c.Set(key, key, ttl); err != nil {
				t.Fatal(err)
			}
		}
		set(1, time.Minute)
		set(2, 2*time.Minute)
		synctest.Wait()
		time.Sleep(30 * time.Second)
		set(1, 2*time.Minute)
		set(3, 10*time.Second)
		synctest.Wait()
		time.Sleep(10 * time.Second)
		synctest.Wait()
		if _, ok := c.Get(3); ok {
			t.Fatal("expired value readable")
		}
		if _, ok := c.items.Load(3); ok {
			t.Fatal("earlier deadline did not clean")
		}
		if value, ok := c.Get(1); !ok || value != 1 {
			t.Fatal("refresh lost")
		}
		time.Sleep(80 * time.Second)
		synctest.Wait()
		if _, ok := c.items.Load(2); ok {
			t.Fatal("second deadline did not clean")
		}
		if _, ok := c.Get(1); !ok {
			t.Fatal("old deadline removed refresh")
		}
		c.Delete(1)
		set(1, time.Minute)
		synctest.Wait()
		time.Sleep(30 * time.Second)
		synctest.Wait()
		if _, ok := c.Get(1); !ok {
			t.Fatal("old node removed reinsertion")
		}
		time.Sleep(30 * time.Second)
		synctest.Wait()
		if _, ok := c.items.Load(1); ok {
			t.Fatal("reinsertion did not expire")
		}
		assertExperimentInvariants(t, c)
	})
}
