from pathlib import Path
import re,statistics,json
root=Path(__file__).parent

def micro(path):
 result={}
 for line in path.read_text().splitlines():
  m=re.match(r'BenchmarkExperiment/(\w+)/(DoubleLock|SyncMap)(?:-(\d+))?\s+\d+\s+([\d.]+) ns/op\s+([\d.]+) GC/Mop\s+(\d+) B/op\s+(\d+) allocs/op',line)
  if m:result.setdefault((m[1],m[2],m[3] or '1'),[]).append([float(x) for x in m.groups()[3:]])
 return result

def median(records,index=0):return statistics.median([r[index] for r in records])
def dns(value):
 m=re.fullmatch(r'([\d.]+)(ns|µs|ms|s)',value)
 return float(m[1])*{'ns':1,'µs':1000,'ms':1000000,'s':1000000000}[m[2]]
def fmt(ns):
 return f'{ns/1e6:.3f} ms' if ns>=1e6 else f'{ns/1e3:.3f} µs'

def expiry(path):
 result={};key=None;memory={}
 for line in path.read_text().splitlines():
  m=re.match(r'=== RUN   TestExperimentExpiryContinuous/(\w+)/N=(\d+)',line)
  if m:key=(m[1],int(m[2]))
  m=re.search(r'(DoubleLock|SyncMap) wave=\d+ cleanup=(\S+) reads=(\d+) p50<=(\S+) p99<=(\S+) max=(\S+) over10us=(\d+) over1ms=(\d+)',line)
  if m:
   name,cleanup,reads,p50,p99,maxlat,slow10,slow1=m.groups()
   result.setdefault((*key,name),[]).append([dns(cleanup),int(reads),dns(p50),dns(p99),dns(maxlat),int(slow10)/int(reads)*100,int(slow1)/int(reads)*100])
  m=re.search(r'(DoubleLock|SyncMap) run=\d+ retained=(\d+) bytes .* objects=(\d+)',line)
  if m:memory.setdefault(m[1],[]).append([int(m[2]),int(m[3])])
 return result,memory

report='''# sync.Map 与当前双锁 TTL 缓存的隔离实验

结论：`sync.Map + Set 时替换节点` 在多核读密集负载下有明显吞吐收益，但覆盖写入更慢且增加分配，保留内存约翻倍；本次写密集或单核单负载goroutine配置中当前双锁更好。是否采用仍待用户决定。本实验未提交或推送任何改动。

## 实验约束与复现

- 基线：PR #53 `ddb9e7c315c18f908e7ca13c73d43bb26d13ee74` 的真实 `cache.go` / `heap.go`，未修改。
- 候选：仅将索引改为 `sync.Map`，移除 mapMu；写入/删除/清理仍由 heapMu 串行。Set 新建节点，覆盖时按旧 index 替换堆节点再 Fix；发布后的 value/deadline 不再修改，index 只由堆锁保护。
- 两者均为每 key 一个堆节点、相同 TTL/通知逻辑，普通基准均启动后台 worker，TTL=24h。int key / int value；未测字符串、大对象或实际业务分布。
- Apple M3 Pro，darwin arm64，12逻辑CPU。Go 1.24.13 测 GOMAXPROCS=1/12，Go 1.25.14 复查 GOMAXPROCS=12。
- 各微基准6轮，逐轮交替两实现运行顺序，单样本150ms；以中位数汇报。统一接口调用两实现，存在共同的接口调用开销。没有同时运行其他实验；-race只用于正确性验证。
- 并行项目的 ns/op 是整个负载耗时除以操作数，即吞吐折算，**不是单次请求延迟**。每 worker 本地随机数，无每操作全局计数器。
- RunParallel未调用SetParallelism，默认负载goroutine数等于GOMAXPROCS：1或12。普通基准另有后台清理worker；集中过期实验固定12个读取goroutine。未测1个P上12个负载goroutine。
- 内存样本3轮，强制GC后记录10万条缓存相对于构建前的HeapAlloc差值，属于进程级近似。

主要文件：`cache/syncmap_experiment_test.go` 候选实现，`cache/syncmap_comparison_test.go` 公共基准/契约验证，`cache/syncmap_expiry_experiment_test.go` 持续读取期间清理测试，`cache/syncmap_scheduler_experiment_test.go` Go1.25虚拟时间验证。`raw/` 内保留完整输出，`run_micro.py` 交替运行顺序。

```sh
go test -race ./cache -run '^TestExperiment(Model|Concurrent|SyncMapSnapshots|SyncMapScheduler)$' -count=10
go test -c -o cache.test ./cache
python3 run_micro.py ./cache.test 6 micro.txt 1,12
go test ./cache -run '^TestExperiment(Footprint|ExpiryContinuous|Environment)$' -v -count=1
```

分别用对应Go版本运行。旧版本自动排除Go1.25虚拟时间文件。计时不使用-race；完整实验源码和原始输出一并保留。

## 普通操作与并发吞吐

越小越好；每格为6轮中位数，单位ns/op。括号为候选/基线，低于1表示候选更快。

'''
scenarios=['GetHit1024','GetMiss1024','ReadParallel65536','Overwrite1','Overwrite1024','Overwrite65536','SetDelete1024','Mixed95Read65536','Mixed50Read65536','Mixed95ReadHot64']
for version,cpu in [('124','12'),('125','12'),('124','1')]:
 data=micro(root/f'micro{version}.txt')
 report+=f'### Go {"1.24.13" if version=="124" else "1.25.14"} / GOMAXPROCS={cpu}\n\n| 负载 | 当前双锁 | sync.Map替换节点 | 候选/基线 |\n| --- | ---: | ---: | ---: |\n'
 for scenario in scenarios:
  a=data[(scenario,'DoubleLock',cpu)];b=data[(scenario,'SyncMap',cpu)]
  assert len(a)==len(b)==6
  report+=f'| {scenario} | {median(a):.2f} | {median(b):.2f} | {median(b)/median(a):.2f}× |\n'
 report+='\n'
report+='''ReadParallel / Mixed的键由各worker伪随机选择。Mixed95Read=95% Get、5%覆盖Set，Mixed50Read=各50%；Hot64只在64个key间操作，其他混合负载65536个key。SetDelete一次操作是一对Set+Delete，其他每次是一个API调用。命中均校验值，覆盖写入保持条目数不变。

## 分配与GC

Go1.24.13 / GOMAXPROCS=12，中位数。GC/Mop为每百万操作期间发生的进程级GC次数估计，不是GC CPU占比。

| 负载 | 双锁B/op | sync.Map B/op | 双锁allocs/op | sync.Map allocs/op | 双锁GC/Mop | sync.Map GC/Mop |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
'''
data=micro(root/'micro124.txt')
for scenario in ['Overwrite1','Overwrite1024','Overwrite65536','SetDelete1024','Mixed95Read65536','Mixed50Read65536']:
 a=data[(scenario,'DoubleLock','12')];b=data[(scenario,'SyncMap','12')]
 report+=f'| {scenario} | {median(a,2):.1f} | {median(b,2):.1f} | {median(a,3):.1f} | {median(b,3):.1f} | {median(a,1):.2f} | {median(b,1):.2f} |\n'
report+='\n混合读写的allocs/op由Go基准输出取整，0不代表写入不分配；请结合B/op看。覆盖写入候选约2次分配/操作，当前实现原地更新为0。分配profile单独保存，未与其他计时实验并行。\n\n### 10万条保留内存\n\n| Go版本 | 双锁中位数 | sync.Map中位数 | 比值 |\n| --- | ---: | ---: | ---: |\n'
for version in ['124','125']:
 e,m=expiry(root/f'expiry-footprint{version}.txt')
 a=statistics.median([v[0] for v in m['DoubleLock']]);b=statistics.median([v[0] for v in m['SyncMap']])
 report+=f'| {version} | {a/1e6:.3f} MB ({a/100000:.1f} B/key) | {b/1e6:.3f} MB ({b/100000:.1f} B/key) | {b/a:.2f}× |\n'
report+='''
## 持续读取期间集中过期

12个读取goroutine持续读取一个存活key，另一个goroutine执行生产nextDelay，清理1万/10万条到期记录。
同一负载运行5波，两实现交替顺序；没有timer worker、没有Set，直接构建有效堆，隔离清理和Get竞争。
与先前“只在清理开始时排队32个读者”的探针不同，这次覆盖整个清理过程。为了不按请求分配内存，分位数用每个goroutine独立的16子桶/二倍区间直方图近似，上界误差最多约6.25%。
下面P99是**清理期间开始的Get请求**，不是完整业务P99。清理时间含读写竞争和调度，不是纯堆运算时间。
所有样本同时记录最大延迟和慢请求比例，避免只看P99；max取5波最大值，其余指标取各波指标的中位数。

'''
for version in ['124','125']:
 e,m=expiry(root/f'expiry-footprint{version}.txt')
 report+=f'### Go {version}\n\n| 分布/数量 | 实现 | 清理耗时 | Get P99上界 | 最大全部观测 | Get >10µs比例 | Get >1ms比例 |\n| --- | --- | ---: | ---: | ---: | ---: | ---: |\n'
 for shape in ['identical','staggered']:
  for count in [10000,100000]:
   for variant in ['DoubleLock','SyncMap']:
    values=e[(shape,count,variant)]
    assert len(values)==5
    report+=f'| {shape}/{count} | {variant} | {fmt(median(values,0))} | {fmt(median(values,3))} | {fmt(max(v[4] for v in values))} | {median(values,5):.4f}% | {median(values,6):.4f}% |\n'
 report+='\n'
report+='''sync.Map在此场景的P99和清理速度更好，但最大观测延迟仍有毫秒级尖峰，部分样本高于双锁。测试没有定位这些尖峰到调度、GC或内部实现，因此不能把P99改善解读为更低的最大延迟保证。

## 验证与结论边界

候选通过随机操作模型、一key一节点/堆索引不变量、并发读写删除清理、并发关闭、不可变快照、泛型nil/NaN验证，以及Go1.25虚拟时间下提前到期/续期/删除重插/真实清理回归。Go1.25十轮竞态验证、Go1.24三轮竞态验证均保存输出。

数据支持按负载选择：

- 多核、读占比高：sync.Map值得继续评估，可去掉显式map锁；本次95/5与纯读吞吐明显改善。
- 写入/续期频繁、本次单核单负载goroutine配置或重视内存：当前双锁更有优势。候选覆盖写入更慢，有每次约百字节分配，保留内存约2倍。
- 当前样本不足以确定真实业务的临界读写比例，没有测实际业务访问轨迹、字符串/大型value、其他架构或GC配置，也没有做统计显著性检验。

本次只提供测量结果。原PR和原子模块不修改、不提交、不推送；是否替换实现等待用户决定。
'''
(root/'report.md').write_text(report)
print(root/'report.md')
