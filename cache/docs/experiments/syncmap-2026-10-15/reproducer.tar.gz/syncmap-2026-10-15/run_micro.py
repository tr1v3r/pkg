from pathlib import Path
import subprocess,sys
binary=sys.argv[1]; rounds=int(sys.argv[2]); outfile=Path(sys.argv[3]); cpus=sys.argv[4]
with outfile.open('w') as out:
 for iteration in range(rounds):
  order=['DoubleLock','SyncMap'] if iteration%2==0 else ['SyncMap','DoubleLock']
  for variant in order:
   out.write(f'ROUND {iteration+1} VARIANT {variant}\n');out.flush()
   subprocess.run([binary,'-test.run=^$','-test.bench=^BenchmarkExperiment$/./'+variant+'$','-test.benchtime=150ms','-test.cpu='+cpus,'-test.benchmem'],stdout=out,stderr=subprocess.STDOUT,check=True)
   out.flush();print(f'round={iteration+1} {variant} complete',flush=True)
