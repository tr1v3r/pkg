#!/bin/sh
set -eu
cd "$(dirname "$0")"
stress_name="pkg-lock-load-repro-$(date +%s)"
docker run --detach --rm --name "$stress_name" \
  --label codex.task=pkg-lock-load-repro \
  --publish 127.0.0.1::6379 --memory 512m --cpus 2 \
  redis@sha256:858f009f9709ce576febc734aa78b8f6d624b82571f9ddb6bda4377c833b3499 \
  redis-server --save '' --appendonly no
trap 'docker rm --force "$stress_name" >/dev/null 2>&1 || true' EXIT
stress_addr=$(docker port "$stress_name" 6379/tcp)
cd source
env -u GOROOT GOTOOLCHAIN=go1.25.7 go build -o ../lockstress ./cmd/lockstress
env -u GOROOT GOTOOLCHAIN=go1.25.7 go build -race -o ../lockstress-race ./cmd/lockstress
cd ..
python3 -u run.py --addr "$stress_addr" --kind perf --repeats 3
python3 -u run.py --addr "$stress_addr" --kind race --repeats 1
