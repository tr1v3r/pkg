#!/usr/bin/env python3
"""Run isolated lock workloads sequentially; JSON files are the source of truth."""
import argparse
import json
import random
import subprocess
import time
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--addr', required=True)
parser.add_argument('--kind', choices=['perf', 'race'], default='perf')
parser.add_argument('--repeats', type=int, default=3)
args = parser.parse_args()
root = Path(__file__).resolve().parent
out = root / args.kind
out.mkdir(exist_ok=True)
binary = root / ('lockstress-race' if args.kind == 'race' else 'lockstress')
cases = []
for workers in ([100, 1000] if args.kind == 'perf' else [1000]):
    cases += [('gate-hot', workers, 3, 64), ('gate-many', workers, 30, 64),
              ('lease-hot', workers, 1, 64), ('lease-many', workers, 10, 64)]
cases += [('auto', 1000, 1, 64)]
if args.kind == 'perf':
    cases += [('auto', 5000, 1, 64), ('gate-many', 1000, 30, 256),
              ('lease-many', 1000, 10, 256), ('auto', 5000, 1, 256)]
results = []
for repeat in range(1, args.repeats + 1):
    ordered = list(cases)
    random.Random(53 + repeat).shuffle(ordered)
    for scenario, workers, iterations, pool in ordered:
        name = f'{scenario}-n{workers}-pool{pool}-r{repeat}'
        command = [str(binary), '-addr', args.addr, '-scenario', scenario,
                   '-workers', str(workers), '-iterations', str(iterations),
                   '-pool', str(pool), '-clients', '4', '-procs', '12',
                   '-ttl', '3s', '-hold', '7s', '-op-timeout', '2s']
        start = time.time()
        try:
            run = subprocess.run(command, capture_output=True, text=True, timeout=95)
            (out / f'{name}.json').write_text(run.stdout)
            (out / f'{name}.stderr').write_text(run.stderr)
            result = json.loads(run.stdout)
            result.update(run=name, exit_code=run.returncode, command=command)
            results.append(result)
            print(f'{name}: exit={run.returncode}, ops/s={result["operations_per_s"]:.0f}, '
                  f'P99={result["operation"]["p99_ms"]:.2f}ms, '
                  f'errors={result["operation"]["errors"]}, '
                  f'lost={result["lost_leases"]}, G_after={result["goroutines_after"]}', flush=True)
        except Exception as error:
            results.append(dict(run=name, harness_error=str(error), command=command))
            print(f'{name}: HARNESS ERROR: {error}', flush=True)
        (out / 'results.json').write_text(json.dumps(results, indent=2))
        (out / 'commands.json').write_text(json.dumps([r['command'] for r in results], indent=2))
print(f'Finished {len(results)} cases; results={out / "results.json"}', flush=True)

if any(r.get("failed", True) or r.get("exit_code", 1) != 0 for r in results):
    raise SystemExit(1)
