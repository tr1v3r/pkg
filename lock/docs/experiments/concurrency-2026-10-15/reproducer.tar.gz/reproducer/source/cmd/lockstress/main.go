package main

import (
	"context"
	"crypto/rand"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"math"
	"os"
	"runtime"
	"sort"
	"sync"
	"sync/atomic"
	"time"

	goredis "github.com/redis/go-redis/v9"
	"github.com/tr1v3r/pkg/lock"
	redisdriver "github.com/tr1v3r/pkg/lock/driver/redis"
)

type distribution struct {
	Count   int     `json:"count"`
	Success int     `json:"success"`
	Busy    int     `json:"busy"`
	Errors  int     `json:"errors"`
	P50     float64 `json:"p50_ms"`
	P95     float64 `json:"p95_ms"`
	P99     float64 `json:"p99_ms"`
	Max     float64 `json:"max_ms"`
}
type samples struct {
	mu                      sync.Mutex
	values                  []time.Duration
	success, busy, failures int
	details                 map[string]int
}

func (s *samples) add(d time.Duration, ok bool, err error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.values = append(s.values, d)
	if err != nil {
		s.failures++
		if s.details == nil {
			s.details = make(map[string]int)
		}
		s.details[err.Error()]++
	} else if ok {
		s.success++
	} else {
		s.busy++
	}
}
func (s *samples) summary() distribution {
	s.mu.Lock()
	defer s.mu.Unlock()
	v := append([]time.Duration(nil), s.values...)
	sort.Slice(v, func(i, j int) bool { return v[i] < v[j] })
	q := func(p float64) float64 {
		if len(v) == 0 {
			return 0
		}
		return float64(v[max(0, int(math.Ceil(p*float64(len(v))))-1)]) / float64(time.Millisecond)
	}
	return distribution{len(v), s.success, s.busy, s.failures, q(.5), q(.95), q(.99), q(1)}
}

type traceDriver struct {
	lock.Driver
	acquire, renew, release *samples
	owners                  *sync.Map
}

func (d traceDriver) TryAcquire(ctx context.Context, key, owner string, ttl time.Duration) (bool, error) {
	t := time.Now()
	ok, err := d.Driver.TryAcquire(ctx, key, owner, ttl)
	d.acquire.add(time.Since(t), ok, err)
	if ok && err == nil && d.owners != nil {
		d.owners.Store(key, owner)
	}
	return ok, err
}
func (d traceDriver) Renew(ctx context.Context, key, owner string, ttl time.Duration) (bool, error) {
	t := time.Now()
	ok, err := d.Driver.Renew(ctx, key, owner, ttl)
	d.renew.add(time.Since(t), ok, err)
	return ok, err
}
func (d traceDriver) Release(ctx context.Context, key, owner string) (bool, error) {
	t := time.Now()
	ok, err := d.Driver.Release(ctx, key, owner)
	d.release.add(time.Since(t), ok, err)
	return ok, err
}

type poolSummary struct {
	WaitCount uint64  `json:"wait_count"`
	WaitMS    float64 `json:"aggregate_wait_ms"`
	Timeouts  uint64  `json:"timeouts"`
	Conns     uint64  `json:"connections"`
}

func poolStats(clients []*goredis.Client) poolSummary {
	var r poolSummary
	for _, c := range clients {
		s := c.PoolStats()
		r.WaitCount += uint64(s.WaitCount)
		r.WaitMS += float64(s.WaitDurationNs) / 1e6
		r.Timeouts += uint64(s.Timeouts)
		r.Conns += uint64(s.TotalConns)
	}
	return r
}
func parallel(n int, fn func(int)) {
	var wg sync.WaitGroup
	start := make(chan struct{})
	wg.Add(n)
	for i := 0; i < n; i++ {
		go func(i int) { defer wg.Done(); <-start; fn(i) }(i)
	}
	close(start)
	wg.Wait()
}
func main() {
	addr := flag.String("addr", "127.0.0.1:6379", "isolated Redis endpoint")
	scenario := flag.String("scenario", "gate-hot", "gate-hot/gate-many/lease-hot/lease-many/auto")
	workers := flag.Int("workers", 1000, "concurrent workload goroutines/live leases")
	iterations := flag.Int("iterations", 30, "operations per worker (auto ignores)")
	pool := flag.Int("pool", 64, "total maximum active connections")
	clientCount := flag.Int("clients", 4, "independent go-redis clients sharing the namespace")
	procs := flag.Int("procs", 12, "GOMAXPROCS")
	hold := flag.Duration("hold", 7*time.Second, "auto-renew observation after acquisition")
	ttl := flag.Duration("ttl", 3*time.Second, "auto-renew TTL")
	opTimeout := flag.Duration("op-timeout", 2*time.Second, "each driver operation bound")
	critical := flag.Duration("critical", 100*time.Microsecond, "lease-hot critical section")
	flag.Parse()
	if *workers < 1 || *iterations < 1 || *clientCount < 1 || *pool < *clientCount || *pool%*clientCount != 0 {
		panic("invalid load/pool")
	}
	switch *scenario {
	case "gate-hot", "gate-many", "lease-hot", "lease-many", "auto":
	default:
		panic("invalid scenario")
	}
	runtime.GOMAXPROCS(*procs)
	baseline := runtime.NumGoroutine()
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	prefix := "pkg-lock-stress:" + rand.Text() + ":"
	acq, ren, rel, top := &samples{}, &samples{}, &samples{}, &samples{}
	var owners sync.Map
	clients := make([]*goredis.Client, *clientCount)
	lockers := make([]*lock.Locker, *clientCount)
	for i := range clients {
		c := goredis.NewClient(&goredis.Options{Addr: *addr, ContextTimeoutEnabled: true, MaxRetries: -1, PoolSize: *pool / *clientCount, MaxActiveConns: *pool / *clientCount, MinIdleConns: *pool / *clientCount, PoolTimeout: *opTimeout, ReadTimeout: *opTimeout, WriteTimeout: *opTimeout})
		clients[i] = c
		if err := c.Ping(ctx).Err(); err != nil {
			panic(err)
		}
		d, err := redisdriver.New(c, prefix)
		if err != nil {
			panic(err)
		}
		tr := traceDriver{Driver: d, acquire: acq, renew: ren, release: rel}
		if *scenario == "auto" {
			tr.owners = &owners
		}
		opts := []lock.Option{lock.WithOperationTimeout(*opTimeout), lock.WithRetryInterval(10 * time.Millisecond)}
		if *scenario == "auto" {
			opts = append(opts, lock.WithAutoRenew())
		}
		lockers[i], err = lock.New(tr, opts...)
		if err != nil {
			panic(err)
		}
	}
	// Warm the bounded connection pools before timing the workload.
	parallel(*pool, func(i int) {
		if err := clients[i%len(clients)].Ping(ctx).Err(); err != nil {
			panic(err)
		}
	})
	beforePool := poolStats(clients)
	var peakG, peakHeap atomic.Uint64
	var mem runtime.MemStats
	runtime.ReadMemStats(&mem)
	initialHeap := mem.HeapAlloc
	sample := func() {
		var m runtime.MemStats
		runtime.ReadMemStats(&m)
		g := uint64(runtime.NumGoroutine())
		for old := peakG.Load(); g > old; old = peakG.Load() {
			if peakG.CompareAndSwap(old, g) {
				break
			}
		}
		for old := peakHeap.Load(); m.HeapAlloc > old; old = peakHeap.Load() {
			if peakHeap.CompareAndSwap(old, m.HeapAlloc) {
				break
			}
		}
	}
	sample()
	stopSample, stopped := make(chan struct{}), make(chan struct{})
	go func() {
		defer close(stopped)
		ticker := time.NewTicker(20 * time.Millisecond)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				sample()
			case <-stopSample:
				return
			}
		}
	}()
	var callbacks, violations, active, lost, notRenewed, remoteMismatch atomic.Int64
	type record struct {
		lease   *lock.Lease
		initial time.Time
		key     string
	}
	var records []record
	started := time.Now()
	switch *scenario {
	case "gate-hot", "gate-many":
		parallel(*workers, func(i int) {
			for j := 0; j < *iterations; j++ {
				key := fmt.Sprintf("hot:%d", j)
				if *scenario == "gate-many" {
					key = fmt.Sprintf("many:%d:%d", i, j)
				}
				t := time.Now()
				ok, err := lockers[i%len(lockers)].TryRun(ctx, key, time.Minute, func(context.Context) error { callbacks.Add(1); return nil })
				top.add(time.Since(t), ok, err)
			}
		})
		expected := int64(*iterations)
		if *scenario == "gate-many" {
			expected *= int64(*workers)
		}
		if callbacks.Load() != expected {
			violations.Add(1)
		}
	case "lease-hot", "lease-many":
		parallel(*workers, func(i int) {
			for j := 0; j < *iterations; j++ {
				key := "hot"
				if *scenario == "lease-many" {
					key = fmt.Sprintf("many:%d", i)
				}
				t := time.Now()
				var lease *lock.Lease
				var err error
				if *scenario == "lease-hot" {
					wait, stop := context.WithTimeout(ctx, 20*time.Second)
					lease, err = lockers[i%len(lockers)].Lock(wait, key, 5*time.Second)
					if err == nil {
						if active.Add(1) != 1 {
							violations.Add(1)
						}
						time.Sleep(*critical)
						if lease.Err() != nil {
							lost.Add(1)
						}
						active.Add(-1)
						err = lease.Release(ctx)
					}
					stop()
				} else {
					lease, err = lockers[i%len(lockers)].TryLock(ctx, key, 5*time.Second)
					if err == nil {
						err = lease.Renew(ctx)
						releaseErr := lease.Release(ctx)
						err = errors.Join(err, releaseErr)
					}
				}
				top.add(time.Since(t), err == nil, err)
			}
		})
	case "auto":
		records = make([]record, *workers)
		parallel(*workers, func(i int) {
			key := fmt.Sprintf("auto:%d", i)
			t := time.Now()
			lease, err := lockers[i%len(lockers)].TryLock(ctx, key, *ttl)
			top.add(time.Since(t), err == nil, err)
			if err == nil {
				records[i] = record{lease, lease.Deadline(), key}
			}
		})
		// Every acquired lease is checked at the end of the full hold period.
		timer := time.NewTimer(*hold)
		select {
		case <-timer.C:
		case <-ctx.Done():
		}
		timer.Stop()
		for _, r := range records {
			if r.lease == nil {
				continue
			}
			if r.lease.Err() != nil {
				lost.Add(1)
			}
			if !r.lease.Deadline().After(r.initial) {
				notRenewed.Add(1)
			}
		}
		verify, stop := context.WithTimeout(context.Background(), 5*time.Second)
		cmds, err := clients[0].Pipelined(verify, func(p goredis.Pipeliner) error {
			for _, r := range records {
				if r.lease != nil {
					p.Get(verify, prefix+r.key)
				}
			}
			return nil
		})
		if err != nil {
			remoteMismatch.Add(1)
		} else {
			idx := 0
			for _, r := range records {
				if r.lease == nil {
					continue
				}
				owner, _ := owners.Load(r.key)
				value, err := cmds[idx].(*goredis.StringCmd).Result()
				idx++
				if err != nil || value != owner {
					remoteMismatch.Add(1)
				}
			}
		}
		stop()
	}
	measured := time.Since(started)
	// Stop every auto worker before closing clients. Release latency is recorded
	// by the driver but is excluded from the acquisition/hold measurement.
	if *scenario == "auto" {
		parallel(len(records), func(i int) {
			r := records[i]
			if r.lease != nil {
				releaseCtx, stop := context.WithTimeout(context.Background(), 5*time.Second)
				_ = r.lease.Release(releaseCtx)
				stop()
			}
		})
	}
	sample()
	close(stopSample)
	<-stopped
	afterPool := poolStats(clients)
	afterPool.WaitCount -= beforePool.WaitCount
	afterPool.WaitMS -= beforePool.WaitMS
	afterPool.Timeouts -= beforePool.Timeouts
	// Remove only this run's namespace, never FLUSHDB or unrelated keys.
	cleanup, stop := context.WithTimeout(context.Background(), 10*time.Second)
	var cursor uint64
	for {
		keys, next, err := clients[0].Scan(cleanup, cursor, prefix+"*", 1000).Result()
		if err != nil {
			panic(err)
		}
		if len(keys) > 0 {
			if err := clients[0].Del(cleanup, keys...).Err(); err != nil {
				panic(err)
			}
		}
		cursor = next
		if cursor == 0 {
			break
		}
	}
	stop()
	for _, c := range clients {
		_ = c.Close()
	}
	runtime.GC()
	time.Sleep(100 * time.Millisecond)
	topSummary := top.summary()
	acquireSummary, renewSummary, releaseSummary := acq.summary(), ren.summary(), rel.summary()
	failed := topSummary.Errors+acquireSummary.Errors+renewSummary.Errors+releaseSummary.Errors > 0 || violations.Load()+lost.Load()+notRenewed.Load()+remoteMismatch.Load() > 0
	reportedTTL := *ttl
	if *scenario == "gate-hot" || *scenario == "gate-many" {
		reportedTTL = time.Minute
	} else if *scenario != "auto" {
		reportedTTL = 5 * time.Second
	}
	result := map[string]any{
		"scenario": *scenario, "workers": *workers, "iterations": *iterations, "clients": *clientCount, "pool_limit": *pool, "gomaxprocs": runtime.GOMAXPROCS(0), "num_cpu": runtime.NumCPU(), "go": runtime.Version(), "os": runtime.GOOS, "arch": runtime.GOARCH,
		"source": "6168a828463241acc28db1e500fcc8676dea5016", "ttl_ms": reportedTTL.Milliseconds(), "hold_ms": hold.Milliseconds(), "critical_us": critical.Microseconds(), "operation_timeout_ms": opTimeout.Milliseconds(), "retry_ms": 10, "elapsed_s": measured.Seconds(), "operations_per_s": float64(topSummary.Count) / measured.Seconds(), "operation": topSummary,
		"acquire_rpc": acquireSummary, "renew_rpc": renewSummary, "release_rpc": releaseSummary, "pool": afterPool, "callbacks": callbacks.Load(), "overlap_or_count_violations": violations.Load(), "lost_leases": lost.Load(), "not_renewed": notRenewed.Load(), "remote_owner_mismatches": remoteMismatch.Load(),
		"goroutines_before": baseline, "goroutines_peak": peakG.Load(), "goroutines_after": runtime.NumGoroutine(), "heap_before_bytes": initialHeap, "heap_peak_bytes": peakHeap.Load(), "errors": map[string]any{"operation": top.details, "acquire": acq.details, "renew": ren.details, "release": rel.details}, "failed": failed,
	}
	if err := json.NewEncoder(os.Stdout).Encode(result); err != nil {
		panic(err)
	}
	if failed {
		os.Exit(1)
	}
}
